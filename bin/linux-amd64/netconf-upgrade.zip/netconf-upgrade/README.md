# IOS XR NCS540 NETCONF upgrade conversion

This is a NETCONF-only conversion draft of the supplied playbook. It contains no
CLI `cmd:` steps, interactive `yes` replies, or SSH CLI probe connections. It uses
the `netconf` SSH subsystem on port 22. It has not been run against a live router.
Use collector version `2.0.4-netconf-upgrade` or newer; `2.0.4-netconf-port` alone
does not implement the new reconnection operation or XML snapshot parser.

## Before running

1. Put your existing `inventory.yaml` alongside these files. The included
   `inventory.example.yaml` contains only a documentation address.
2. Run `discover-models.yaml` first to check the required models on the actual
   router. This workbook only requests YANG schemas. The full playbook repeats
   these checks before any mutation and stops if a required schema is unavailable.
3. Create a private `upgrade-secrets.yaml` using the shape in
   `upgrade-secrets.example.yaml`. Supply a router-generated Type-10 hash for
   the temporary `ios_install` user's secret, not the plaintext password from
   the upload. The uploaded password was not copied. Keep this file owner-only
   (`chmod 600 upgrade-secrets.yaml`) and out of Git. The example placeholder is
   not a usable hash. Verify ordering-index `1` is appropriate for this temporary
   user on your router. This process expects the temporary user to be absent
   initially; do not overwrite an existing account.
4. Confirm the image path, the five package names, the target label `26.2.2`,
   FPD status spellings and permissions against the actual router. The image is
   assumed already present on `harddisk:/`; this workflow does not upload it.
5. Check `0/RP0/CPU0` is the correct cold-reboot target for your NCS540. The native
   `reboot-request` is a cold reboot of that entity, not a literal translation
   of entering the admin CLI and executing `reload rack 0`. A chassis with
   different reload semantics needs a platform-specific equivalent.
6. The original modern/insecure SSH policy is preserved in both generated
   workbooks. You can use your normal verified host-key configuration instead.

Offline check (does not connect):

```
./network-collector --config config.netconf.yaml --lint
```

Read-only model discovery (connects, does not configure or reboot):

```
./network-collector --config discover-models.yaml
```

Run the upgrade only after those checks and review of the draft:

```
./network-collector --config config.netconf.yaml
```

## Conversion details

- Corrected the source typo `start_internal_seconds` to `start_interval_seconds`.
- Kept max_parallel 3, canary_count 1 and failure_threshold 2.
- The install actions use `Cisco-IOS-XR-spirit-install-act` (classic install),
  not the different `Cisco-IOS-XR-install-act` action family. Adding, activating,
  deactivating, committing and removing packages return operation IDs. The
  collector validates each ID as a bounded integer, then polls the matching
  `install/request` for `state=success` with no error. Other operations' success
  does not satisfy this check. RPC acknowledgement alone is not completion.
- Activation uses `install-activate/reload/ids` with the add operation ID.
  There is no CLI confirmation question. No mutating RPC is automatically
  replayed after a transport failure; missing acknowledgement stops the host
  because the router may have accepted the request.
- Each reboot is followed by 840 seconds of waiting (the original 600+240),
  then up to 40 NETCONF connection/hello attempts, 60 seconds apart. Connection
  establishment uses `timeout` (30 seconds by default), separately from the
  1800-second RPC `operation_timeout`. This is
  actual NETCONF readiness, not an open TCP port or a CLI login.
- FPD actions use `upgrade-fpd` and `reboot-request`. Readable FPD status is
  required before conditional actions. `when` conditions choose the upgrade
  and reload paths; detecting a required action is not recorded as a failed
  host check. Progress polling retains the original 15-attempt/60-second budget.
- A five-second delay in `reboot-request` allows an `<ok/>` acknowledgement
  before the connection drops. The collector never assumes a dropped RPC is
  successful. Verify that behaviour on the router.
- Temporary user configuration is native candidate/edit-config/commit using
  the AAA models. NETCONF configuration commit and software install-commit
  are different operations and are kept separate.
- Final software verification checks the exact installed label, not a loose
  substring in CLI output. File deletion uses `shellutil-delete-act`; its
  textual success response must match `success|deleted` and no error marker.
  Confirm that response against the device before relying on the cleanup step.
- Alarm, IS-IS and interface comparisons use filtered native operational data
  and the `xml_snapshot` parser. It ignores namespace-prefix spelling, sibling
  order, envelope message IDs and insignificant whitespace while retaining
  namespace URIs and record associations. Missing model roots fail rather than
  comparing two empty responses. IS-IS uptime/hold timers and alarm set times
  are not requested. Interface `briefs` contain modelled operational data;
  compare a pre/post capture if the platform adds volatile leaves there.
- Changes in final checks stop the host. The temporary user is removed after
  successful upgrade/cleanup, as in the original. Failed workflows may leave
  it present; inspect and remove it after resolving the failure.

## Sources and limits

RPC and subtree names were checked against published IOS XR 25.2.2 models in
YangModels/yang, pinned at commit
`8b2414f42773a6fa97251ae8e7e3006649dff6d1`, under `vendor/cisco/xr/2522`:

https://github.com/YangModels/yang/tree/8b2414f42773a6fa97251ae8e7e3006649dff6d1/vendor/cisco/xr/2522

Required models are listed in `discover-models.yaml`. Published source models
are not proof that the installed 25.2.21/26.2.2 images implement every action,
leaf, value, or response identically. Model discovery and a live lab check remain
necessary. The generated files have been checked offline, not used to operate
or upgrade a device. There is no automatic rollback of software activation.
